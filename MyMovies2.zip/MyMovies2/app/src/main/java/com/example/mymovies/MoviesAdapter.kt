package com.example.mymovies

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CenterCrop

class MoviesAdapter(
    private var movies: MutableList<Movie>,
    private val onMovieClick: (movie: Movie) ->   Unit
) : RecyclerView.Adapter<MoviesAdapter.MovieViewHolder>() {

    fun appendMovies(newMovies: List<Movie>) {
        val oldSize = this.movies.size
        this.movies.addAll(newMovies)
        notifyItemRangeInserted(
            this.movies.size,
            movies.size - 1
      )
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_movie, parent, false)
        return MovieViewHolder(view)
    }

    override fun getItemCount(): Int = movies.size

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        holder.bind(movies[position])
    }

    /**
     * Replaces the current list of movies and refreshes the RecyclerView.
     */
    fun updateMovies(newMovies: List<Movie>) {
        this.movies = newMovies.toMutableList()
        notifyDataSetChanged()
    }

    inner class MovieViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val poster: ImageView = itemView.findViewById(R.id.item_movie_poster)

        fun bind(movie: Movie) {
            Glide.with(itemView)
                .load("https://image.tmdb.org/t/p/w342${movie.posterPath}")
                .transform(CenterCrop())
                .into(poster)
            itemView.setOnClickListener  {  onMovieClick.invoke(movie)  }
        }
    }
}
